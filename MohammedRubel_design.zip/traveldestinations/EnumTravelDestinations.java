package source.assign.traveldestinations;
/**
 * ENUM for Travel Destinations
 */
public enum EnumTravelDestinations {
    RELIGIOUS, HIKING, BEACHES,VINYARDS
}
